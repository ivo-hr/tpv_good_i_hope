#pragma once

#include "Command.h"
#include "QuitCommand.h"
#include "MoveCommand.h"
#include "AccCommand.h"
#include "HelpCommand.h"
#include "ShootCommand.h"
#include "BlastCommand.h"
#include "DebugCommand.h"
#include "WaveCommand.h"
#include "NextCommand.h"
#include "ShieldCommand.h"